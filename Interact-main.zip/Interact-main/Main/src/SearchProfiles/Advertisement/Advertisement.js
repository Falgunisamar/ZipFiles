import React from "react"

export default function AdvertisementPoster(){
    
return (
    <div className="flex justify-center w-full  "> 
   <a href="https://devfolio.co/" target="_blank"><img src="Poster.png" className=" w-60  py-2  sm:w-[80vw] sm:h-max-[30vh] "/></a>
    </div>
)
}