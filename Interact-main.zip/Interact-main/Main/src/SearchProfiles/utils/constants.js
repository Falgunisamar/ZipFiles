export const filter = [{
  name:'userName'
},
{
  name:'designation'
},
{
  name:'skill'
},
{
  name:'location'
},
{
  name:'about'
},{
  name:'all'
}
  ];
